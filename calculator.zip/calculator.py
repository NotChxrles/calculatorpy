# first calculator program
from tkinter import *

#the window frame of the gui
root = Tk()
root.title("Simple Calculator")

# Functions for arithmetic operations
def calculate():
    expression = entry.get()
    try:
        result = eval(expression)
        entry.delete(0, END)
        entry.insert(END, str(result))
    except Exception as e:
        entry.delete(0, END)
        entry.insert(END, "Error!")
        
def clear():
    entry.delete(0, END)        

#Functions
def button_click(value):
    current = entry.get()
    entry.delete(0, END)
    entry.insert(END, str(current) + str(value))
    
# widgets
    # Entry
entry = Entry(root, width=50, borderwidth=1)
entry.grid(row=0, column=1, columnspan=4, padx=10, pady=10)

# Buttons
button_16=Button(root, text="C", command=clear, width=10, height=2, padx=5, pady=5)
button_16.grid(row=1, column=1)
button_17=Button(root, text="÷", command=lambda:button_click('/'), width=10, height=2, padx=5, pady=5)
button_17.grid(row=1, column=2)
button_18=Button(root, text="←", command=lambda: entry.delete(len(entry.get()) - 1, END,), width=10, height=2, padx=5, pady=5)
button_18.grid(row=1, column=3, columnspan=2, sticky='ew')

button_1 = Button(root, text ="7", command=lambda: button_click(7), width=10, height=2, padx=5, pady=5)
button_1.grid(row=2, column=1)
button_2 = Button(root, text="8", command=lambda: button_click(8), width=10, height=2, padx=5, pady=5)
button_2.grid(row=2, column=2)
button_3 = Button(root, text="9", command=lambda: button_click(9), width=10, height=2, padx=5, pady=5)
button_3.grid(row=2, column=3)
button_4 = Button(root, text="*", command=lambda: button_click('*'), width=10, height=2, padx=5, pady=5)
button_4.grid(row=2, column=4)

button_5 =Button(root, text="4", command=lambda: button_click(4), width=10, height=2, padx=5, pady=5)
button_5.grid(row=3, column=1)
button_6 =Button(root, text="5", command=lambda: button_click(5), width=10, height=2, padx=5, pady=5)
button_6.grid(row=3, column=2)
button_7 =Button(root, text="6", command=lambda: button_click(6), width=10, height=2, padx=5, pady=5)
button_7.grid(row=3, column=3)
button_8 =Button(root, text="+", command=lambda: button_click('+'), width=10, height=2, padx=5, pady=5)
button_8.grid(row=3, column=4)

button_9 =Button(root, text="1", command=lambda: button_click(1), width=10, height=2, padx=5, pady=5)
button_9.grid(row=4, column=1)
button_10 =Button(root, text="2", command=lambda: button_click(2), width=10, height=2, padx=5, pady=5)
button_10.grid(row=4, column=2)
button_11 =Button(root, text="3", command=lambda: button_click(3), width=10, height=2, padx=5, pady=5)
button_11.grid(row=4, column=3)
button_12 =Button(root, text="-", command=lambda: button_click('-'),  width=10, height=2, padx=5, pady=5)
button_12.grid(row=4, column=4)

button_13 = Button(root, text="0", command=lambda: button_click(0), width=10, height=2, padx=5, pady=5)
button_13.grid(row=5, column=1)
button_14 =Button(root, text=",", command=lambda: button_click(','), width=10, height=2, padx=5, pady=5)
button_14.grid(row=5, column=2)
button_15=Button(root, text="=", command=calculate, width=10, height=2, padx=5, pady=5)
button_15.grid(row=5, column=3, columnspan=2, sticky='ew')

#Start gui loop
root.mainloop()